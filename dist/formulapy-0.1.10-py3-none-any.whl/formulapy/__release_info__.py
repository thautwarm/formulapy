__VERSION__ = '0.1.10'
__AUTHOR__ = "thautwarm"